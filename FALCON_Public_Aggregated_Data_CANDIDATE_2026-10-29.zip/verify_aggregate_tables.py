#!/usr/bin/env python3
"""Check FALCON author-reported 2020 aggregate summaries only; no external data requests."""
from pathlib import Path
import csv, json, math
p=Path(__file__).resolve().parent

def read(name):
    with (p/name).open(newline='',encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))
res=read('BGP_2020_AGGREGATE_WINDOW_RESULTS.csv')
contrast=read('BGP_2020_AGGREGATE_EVENT_REFERENCE_CONTRAST.csv')
sens=read('BGP_2020_FIXED_COHORT_SENSITIVITY_SUMMARY.csv')
ipv6=read('BGP_2020_AS12486_IPV6_RETENTION_SUMMARY.csv')
assert len(res)==12 and len(contrast)==len(sens)==len(ipv6)==6
records={(r['collector'],r['origin_asn'],r['period']):r for r in res}
assert len(records)==12
for r in res:
    count,changed=int(r['comparable_retained_routes']),int(r['origin_adjacent_neighbor_changed'])
    assert 0<=changed<=count
    assert int(r['ipv4_comparable'])+int(r['ipv6_comparable'])==count
    assert math.isclose(100*changed/count,float(r['neighbor_change_percent']),abs_tol=.000001,rel_tol=0)
for r in contrast:
    c,a=r['collector'],r['origin_asn']
    e=records[(c,a,'event')];n=records[(c,a,'reference')]
    assert int(r['event_changed'])==int(e['origin_adjacent_neighbor_changed'])
    assert int(r['reference_changed'])==int(n['origin_adjacent_neighbor_changed'])
    assert int(r['event_comparable'])==int(e['comparable_retained_routes'])
    assert int(r['reference_comparable'])==int(n['comparable_retained_routes'])
    expected=100*(int(e['origin_adjacent_neighbor_changed'])/int(e['comparable_retained_routes'])-int(n['origin_adjacent_neighbor_changed'])/int(n['comparable_retained_routes']))
    assert math.isclose(float(r['event_minus_reference_percentage_points']),expected,abs_tol=.000001,rel_tol=0)
for s in sens:
    assert int(s['same_comparable_peer_prefix_keys_across_both_windows'])>0
    diff=float(s['event_fixed_cohort_change_percent'])-float(s['reference_fixed_cohort_change_percent'])
    assert math.isclose(diff,float(s['fixed_cohort_event_minus_reference_pp']),abs_tol=.000003,rel_tol=0)
for r in ipv6:
    assert 0<=int(r['retained_same_origin_ipv6'])<=int(r['initial_eligible_ipv6'])
print('PASS: 12 aggregate window summaries, 6 ratios and event/reference contrasts, 6 fixed-cohort delta arithmetic checks, 6 IPv6 endpoint-selection summaries. NO original RIS/ IODA data rerun.')
