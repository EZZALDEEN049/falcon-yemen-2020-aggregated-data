# Material deliberately excluded from candidate public data archive

| Original/internal material | Rationale | Alternative in candidate |
|---|---|---|
| Original 12 RIPE RIS MRT `.gz` (large archives) | Third-party data reuse/redistribution terms unconfirmed; too large | Exactly 12 original provider URLs, times, sizes, recorded SHA-256 in `ORIGINAL_RIPE_SOURCE_LINKS_AND_SHA256.csv` |
| RIS per-peer/per-prefix extracted rows, AS_PATH details, peer IP identities and provider-derived distributions | Derived from source data whose redistribution rights are not yet cleared | New small collector×ASN×window author aggregate results, fixed-cohort summary, source retrieval references |
| Source IODA PNGs and 2020 image-extracted pixel traces / 20,250-setting grid | Publisher image adaptation, redistribution license and source-data rights unresolved | Publisher-original URL + prior-audit SHA-256 ONLY, plus methodological limitation in README |
| Provider-original IODA 2023 JSON ZIP and any downstream data-level trace | Terms for source redistribution not verified | Mentioned in README, no ZIP or summary values |
| RIPE Atlas original data and aggregated metadata | Source terms require separate clearance | Not included |
| Manuscript, supplement, internal reviews, author correspondence, superseded versions | Pre-submission privacy and author-approval gate | No copy included |
| Historical CI workflows with signed or expiring download URLs | Unrelated to citable data, possible sensitive links | No copy included |

**Approval gate:** the author must confirm file-level distribution rights for the *author-reported aggregate results*, select scoped license terms or retain all rights, decide public status, and verify no embargo/preprint conflict. This candidate is not to be published by an assistant without that approval.
