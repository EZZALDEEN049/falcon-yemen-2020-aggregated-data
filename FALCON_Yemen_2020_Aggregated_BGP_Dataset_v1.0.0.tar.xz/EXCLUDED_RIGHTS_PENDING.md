# Material deliberately excluded from public aggregate-data archive

| Original/internal material | Rationale | Alternative in dataset |
|---|---|---|
| Original 12 RIPE RIS MRT `.gz` (large archives) | Third-party data reuse/redistribution terms unconfirmed; too large | Exactly 12 original provider URLs, times, sizes, recorded SHA-256 in `ORIGINAL_RIPE_SOURCE_LINKS_AND_SHA256.csv` |
| RIS per-peer/per-prefix extracted rows, AS_PATH details, peer IP identities and provider-derived distributions | Derived from source data whose redistribution rights are not yet cleared | New small collector×ASN×window author aggregate results, fixed-cohort summary, source retrieval references |
| Source IODA PNGs and 2020 image-extracted pixel traces / 20,250-setting grid | Publisher image adaptation, redistribution license and source-data rights unresolved | Publisher-original URL + prior-audit SHA-256 ONLY, plus methodological limitation in README |
| Provider-original IODA 2023 JSON ZIP and any downstream data-level trace | Terms for source redistribution not verified | Mentioned in README, no ZIP or summary values |
| RIPE Atlas original data and aggregated metadata | Source terms require separate clearance | Not included |
| Manuscript, supplement, internal reviews, author correspondence, superseded versions | Pre-submission privacy and author-approval gate | No copy included |
| Historical CI workflows with signed or expiring download URLs | Unrelated to citable data, possible sensitive links | No copy included |

**Release status:** the repository owner explicitly approved public distribution of the author-prepared aggregate package on 29 October 2026. Exclusion of provider-origin and internal material remains in force. Data reuse license is not yet asserted; set/review the license in Zenodo metadata before final DOI publication. This public authorization does not clear rights for any excluded materials.
