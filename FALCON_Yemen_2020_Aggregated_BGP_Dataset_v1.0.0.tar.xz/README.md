# FALCON Yemen 2020 — Public Aggregated BGP Research Dataset (v1.0.0)

**RELEASE SCOPE.** The repository owner explicitly authorized public distribution of this author-prepared aggregate-data package on 29 October 2026. This authorization is limited to the contents of this release; it does not claim rights over excluded provider materials. This release deliberately does not contain original RIPE RIS MRT files, any peer-level or prefix-level RIS-derived observations, original IODA image/JSON files, digitized raster traces, reviewer reports, working manuscripts, private correspondence or other ambiguous third-party copies.

## Scope and scientific status

This *author-written summary package* reports **aggregated descriptive BGP results** observed for AS30873 and AS12486 by RIPE RIS collectors **RRC00, RRC01 and RRC10**, comparing two 16-hour pairs of historical RIB checkpoints:

- Reference: 2020-01-02 08:00 UTC to 2020-01-03 00:00 UTC.
- Event-associated: 2020-01-09 08:00 UTC to 2020-01-10 00:00 UTC.

The earlier interval was retrospectively chosen and fixed **before examining its own outcomes**; it was NOT preregistered before the January 2020 event. A single earlier window is NOT a statistical distribution of ordinary routing churn, not a causally interchangeable control, and not physical proof about FALCON, end-user connectivity, or AS-path transport. BGP observations across peers/prefixes/collectors can be dependent.

## File inventory (only small, high-level aggregates and link-only metadata)

- `BGP_2020_AGGREGATE_WINDOW_RESULTS.csv`: 12 origin×collector×period summary rows; changed/retained-comparable counts and IPv4/IPv6 denominator breakdown.
- `BGP_2020_AGGREGATE_EVENT_REFERENCE_CONTRAST.csv`: six summary contrasts calculated from author-reported numerators and denominators.
- `BGP_2020_FIXED_COHORT_SENSITIVITY_SUMMARY.csv`: six **summary-only** fixed-peer–prefix-cohort checks, without individual peers/prefixes.
- `BGP_2020_AS12486_IPV6_RETENTION_SUMMARY.csv`: six cohort-selection counts, not outage claims.
- `AGGREGATE_FORMULA_AUDIT.json`: integrity checks for six rates/contrasts and six fixed-cohort arithmetic checks. **Not an independent reproduction of original MRT files.**
- `ORIGINAL_RIPE_SOURCE_LINKS_AND_SHA256.csv`: official 12 original RIS RIB URLs, timestamps, sizes and source hashes documented in the research project's prior audit; no original bytes.
- `IODA_2020_PUBLISHER_LINKS_ONLY.csv`: original publisher figure references and their previously documented hashes, with no provider image bytes or raster-derived data.
- `verify_aggregate_tables.py`: deterministic standard-library recalc of aggregate ratios and delta summaries.
- `EXCLUDED_RIGHTS_PENDING.md`: excluded file types and remaining provider-origin redistribution restrictions.
- `FILES_SHA256.json`: file sizes and SHA-256 for each included file except the manifest itself.

## Recalculate the aggregate numbers

Requires **Python 3.10+**; from the unzipped folder:

```bash
python verify_aggregate_tables.py
```

The script checks exact integer numerators/denominators, reported percentages, delta percentage points, fixed-cohort delta arithmetic, and IPv4+IPv6 comparable counts. It cannot reconstruct event/reference counts from provider binaries because those **source data are intentionally absent** pending redistribution-rights clearance. Independent source-native reprocessing requires obtaining the 12 RIPE RIS RIBs from the recorded official URLs, checking the supplied prior-audit hashes, and using an approved source parser and previously published extraction rules (see the broader research repository, particularly `releases/FALCON-v1.0-2026-10-29-reviewer/Code/REPRODUCE.md`). The RIB originals were NOT downloaded during this package-preparation run. The source SHA-256 are **reported from previous audits, not independently reverified in this packaging run**.

The source-row/reviewer bundle is NOT part of this package; therefore this is **arithmetic reproducibility of summary statistics**, not full empirical reproduction. Full reproducibility requires obtaining datasets under the provider's terms.

## Main aggregate comparison

For AS30873, the 3 collectors report reference changed-neighbor rates **0.48%, 0.90%, 0.41%** (RRC00, RRC01, RRC10) versus event-associated **66.83%, 67.98%, 64.73%**. The fixed comparable peer–prefix-cohort sensitivity remains directionally consistent. The AS12486 IPv6 eligible route inventory has 0/54, 0/24, 0/13 retained same-origin endpoint entries in the event-associated interval versus 54/54, 23/23, 13/13 in reference: this is NOT proof of route withdrawal, user outage, or lack of IPv6 transit.

## Rights/provenance

The repository owner confirmed approval for publishing these author-reported aggregate tables on 29 October 2026. This does not assert permission to redistribute RIPE RIS or IODA originals or lower-level derived records. The figures are scientific **author-formulated aggregate estimates** sourced from an archived analysis of RIPE RIS published routing observations. Provider-origin data, data-like extracted records, images and source-owned tabulations are **excluded** when rights remain unclear. Authorization to make the author-prepared aggregates public was stated by the repository owner on 29 October 2026. Specific public-reuse license terms for the aggregate data have not been selected in this package; GitHub visibility itself is not a license. The separate author-owned software release at https://doi.org/10.5281/zenodo.23751733 is MIT-licensed, and its MIT license **does not** cover this dataset.

Researcher: **Ezzaldeen Al-Tayar**, Faculty of Engineering and Information Technology, Taiz University, Taiz, Yemen. The manuscript has not been submitted to or accepted by *Scientific Reports*.

## Associated research software

[Curated FALCON software release (v1.0.1)](https://doi.org/10.5281/zenodo.23751733). This dataset is an independent aggregate-data release, not a replacement for the software archive.
