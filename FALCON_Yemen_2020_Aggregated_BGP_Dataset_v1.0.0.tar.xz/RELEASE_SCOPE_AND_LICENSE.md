# Release scope and rights note

- Public release of the author-prepared aggregate summary tables was approved by the repository owner in this conversation on 29 October 2026.
- The repository excludes all original RIPE RIS MRT files, per-peer or per-prefix extracts, original IODA figures/JSON, raster traces, manuscripts, internal reviews, and private materials.
- Links to provider publications and previously documented SHA-256 hashes are provenance pointers, not a redistribution or independent revalidation of original bytes.
- Arithmetic verification of the aggregate tables does not establish source-native reproducibility or causal attribution to the submarine cable.
- This dataset has no explicit public reuse license text in the package. Repository visibility is not equivalent to a CC BY, MIT or other grant. Before archiving the GitHub release in Zenodo, review the license displayed by Zenodo and confirm author intent.
- The separately archived author-owned software has MIT license: https://doi.org/10.5281/zenodo.23751733.
